<?php
 
class DbOperation
{
    
    private $con;
 
 
    function __construct()
    {
  
        require_once dirname(__FILE__) . '/DbConnect.php';
 
     
        $db = new DbConnect();
 

        $this->con = $db->connect();
    }
	
	
	function createProduto($nome, $fornecedor, $quantidade, $tipo, $rating, $preco, $descricao){
		$stmt = $this->con->prepare("INSERT INTO Produtos (nome, fornecedor, quantidade, tipo, rating, preco, descricao) VALUES (?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("ssssiss", $nome, $fornecedor, $quantidade, $tipo, $rating, $preco, $descricao);
		if($stmt->execute())
			return true; 
		return false; 
	}

	
	function getProduto(){
		$stmt = $this->con->prepare("SELECT id, nome, fornecedor, quantidade, tipo, rating, preco, descricao FROM Produtos");
		$stmt->execute();
		$stmt->bind_result($id, $nome, $fornecedor, $quantidade, $tipo, $rating, $preco, $descricao);
		
		$produtos = array(); 
		
		while($stmt->fetch()){
			$produto  = array();
			$produto['id'] = $id; 
			$produto['nome'] = $nome; 
			$produto['fornecedor'] = $fornecedor; 
			$produto['quantidade'] = $quantidade; 
			$produto['tipo'] = $tipo; 
			$produto['rating'] = $rating; 
			$produto['preco'] = $preco; 
			$produto['descricao'] = $descricao; 
			
			array_push($produtos, $produto); 
		}
		
		return $produtos; 
	}
	
	
	function updateProduto($id, $nome, $fornecedor, $quantidade, $tipo, $rating, $preco, $descricao){
		$stmt = $this->con->prepare("UPDATE produtos SET nome = ?, fornecedor = ?, quantidade = ?, tipo = ?, rating = ?, preco = ?, descricao = ? WHERE id = ?");
		$stmt->bind_param("ssssissi", $nome, $fornecedor, $quantidade, $tipo, $rating, $preco, $descricao, $id);
		if($stmt->execute())
			return true; 
		return false; 
	}
	
	
	
		function deleteProduto($id){
		$stmt = $this->con->prepare("DELETE FROM Produtos WHERE id = ? ");
		$stmt->bind_param("i", $id);
		if($stmt->execute())
			return true; 
		
		return false; 
	}
}
	